#!/bin/bash

# Migration script to version 0.0.3



