#! /bin/sh
# Launch the inspectionapplication at startup

# Script variables
APP_PATH="/home/admin"
APP_NAME="CbRtUnit"

# Check the command line options
case "$1" in

    # Machine start
    start)

        # Start the inspection applicarion
        cd $APP_PATH
        ./$APP_NAME &

        # Show a message
        echo "Inspection application started"
        ;;

    # Machine stop
    stop)

        # Stop the inspection applicarion
        killall -9 $APP_NAME

        # Show a message
        echo "Inspection application stopped"
        ;;

    # Machine restart
    restart)

        # Stop the inspection applicarion
        killall -9 $APP_NAME

        # Start the inspection applicarion
        cd $APP_PATH
        ./$APP_NAME &

        # Show a message
        echo "Inspection application restarted"
        ;;

    # Check if the process is running, if not it starts it
    check)

        # Check if the inspection applicarion is running
        ps cax | grep $APP_NAME > /dev/null
        if [ $? -eq 0 ]; then

                # Show a message
                echo "Inspection application is already running"
        else

                # Start the inspection application
                cd $APP_PATH
                ./$APP_NAME &

                # Show a message
                echo "Inspection application started"
        fi
        ;;
esac

# Exit from the script
exit 0
